const cooldowns = new Map();

function isInCooldown(commandName, userId, config) {
    try {
        // Ensure the command map exists
        if (!cooldowns.has(commandName)) {
            cooldowns.set(commandName, new Map());
        }

        const userCooldowns = cooldowns.get(commandName);

        // Check if user already has a cooldown
        const expirationTime = userCooldowns.get(userId);

        // If the user is not in cooldown, return false
        if (!expirationTime) return false;

        // If current time is less than the expiration time, the user is still in cooldown
        if (Date.now() < expirationTime) {
            const timeLeft = expirationTime - Date.now();
            const hoursLeft = Math.floor(timeLeft / (1000 * 60 * 60));
            const minutesLeft = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            console.log(`Cooldown: User ${userId} has ${hoursLeft}h ${minutesLeft}m left for command ${commandName}`);
            return true;
        }

        // If the cooldown expired, delete the user entry and return false
        userCooldowns.delete(userId);
        return false;
    } catch (error) {
        console.error(`Error checking cooldown for command "${commandName}" and user "${userId}":`, error);
        return false;
    }
}

function setCooldown(commandName, userId, cooldownDuration) {
    try {
        if (!cooldowns.has(commandName)) {
            cooldowns.set(commandName, new Map());
        }

        const userCooldowns = cooldowns.get(commandName);
        const expirationTime = Date.now() + cooldownDuration;

        userCooldowns.set(userId, expirationTime);

        // Automatically clear expired cooldowns
        setTimeout(() => userCooldowns.delete(userId), cooldownDuration);
        console.log(`Cooldown set for user ${userId} on command ${commandName} until ${new Date(expirationTime).toLocaleString()}`);
    } catch (error) {
        console.error(`Error setting cooldown for command "${commandName}" and user "${userId}":`, error);
    }
}

module.exports = { isInCooldown, setCooldown };


function setCooldown(commandName, userId, cooldownTime) {
    try {
        if (!cooldowns.has(commandName)) {
            cooldowns.set(commandName, new Map());
        }

        const userCooldowns = cooldowns.get(commandName);
        const expirationTime = Date.now() + cooldownTime;
        userCooldowns.set(userId, expirationTime);
    } catch (error) {
        console.error(`Error setting cooldown for command ${commandName} and user ${userId}:`, error);
    }
}

function getRemainingCooldown(commandName, userId, config) {
    try {
        if (!cooldowns.has(commandName)) {
            return 0;
        }

        const userCooldowns = cooldowns.get(commandName);
        const expirationTime = userCooldowns.get(userId);
        
        if (!expirationTime) return 0;

        const remainingTime = expirationTime - Date.now();
        return remainingTime > 0 ? remainingTime : 0;
    } catch (error) {
        console.error(`Error getting remaining cooldown for command ${commandName} and user ${userId}:`, error);
        return 0;
    }
}

module.exports = { isInCooldown, setCooldown, getRemainingCooldown };
