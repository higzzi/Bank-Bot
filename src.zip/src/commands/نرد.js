const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'نرد',
    description: 'لعبة نرد مع ميزة المراهنة بالمال',
    async execute(message, db, config, args) {
        try {
            const userId = message.author.id;
            let currentBalance = await db.get(`balance_${userId}`) || 0;

            if (currentBalance <= 0) {
                return message.reply('❌ ليس لديك رصيد كافي للعب نرد.');
            }

            // Check if a valid bet amount is specified
            let betAmount;
            let diceType = args[0];

            switch (diceType) {
                case 'نص':
                    betAmount = Math.round(currentBalance / 2);
                    break;
                case 'ربع':
                    betAmount = Math.round(currentBalance / 4);
                    break;
                case 'كل':
                default:
                    betAmount = currentBalance;
                    break;
            }

            // Ensure user has enough balance to place the bet
            if (currentBalance < betAmount || betAmount <= 0) {
                return message.reply('❌ لا تملك رصيدًا كافيًا للمراهنة.');
            }

            // Roll the dice for user and bot
            const userChoice = Math.floor(Math.random() * 6) + 1; // User rolls a 6-sided dice
            const botChoice = Math.floor(Math.random() * 6) + 1; // Bot rolls a 6-sided dice

            let resultMessage;

            // Determine outcome based on dice rolls
            if (userChoice > botChoice) {
                // User wins (double the bet)
                const winnings = betAmount * 2;
                currentBalance += winnings;
                resultMessage = `🎉 **فزت بالنرد!**\nاخترت: ${userChoice}\nاخترت انا: ${botChoice}\nمبلغ الربح: **$${winnings.toLocaleString()}**\nرصيدك الحالي: **$${currentBalance.toLocaleString()}**`;
            } else if (userChoice < botChoice) {
                // User loses (loses bet amount)
                currentBalance -= betAmount;
                resultMessage = `😢 **خسرت بالنرد...**\nاخترت: ${userChoice}\nاخترت انا: ${botChoice}\nمبلغ الخسارة: **$${betAmount.toLocaleString()}**\nرصيدك الحالي: **$${currentBalance.toLocaleString()}**`;
            } else {
                // Tie (no loss, no gain)
                resultMessage = `⚖️ **تعادل!**\nاخترت: ${userChoice}\nاخترت انا: ${botChoice}\nرصيدك الحالي: **$${currentBalance.toLocaleString()}**`;
            }

            // Update balance in database
            await db.set(`balance_${userId}`, currentBalance);

            // Create row for interactive buttons (Optional, add retry or exit buttons)
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('play_again')
                    .setLabel('لعب مرة أخرى')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(false),
                new ButtonBuilder()
                    .setCustomId('exit_game')
                    .setLabel('خروج')
                    .setStyle(ButtonStyle.Danger)
                    .setDisabled(false)
            );

            // Send result message
            message.reply({
                content: resultMessage,
                allowedMentions: { repliedUser: false },
                ephemeral: true, // الرسالة ستكون مرئية فقط للمستخدم
                components: [row]
            });

        } catch (error) {
            console.error('❌ خطأ أثناء تنفيذ أمر نرد:', error);
            message.reply('⚠️ حدث خطأ أثناء محاولة لعب نرد. يرجى المحاولة مرة أخرى.');
        }
    }
};
