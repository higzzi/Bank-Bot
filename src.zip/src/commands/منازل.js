const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'منازل',
    description: '🏡 عرض قائمة المنازل المتاحة للبيع',
    async execute(message, db, config) {
        try {
            const embed = new EmbedBuilder()
                .setTitle('🏡 قائمة المنازل المتاحة للبيع')
                .setDescription('💰 اشترِ منزلك الآن واستمتع بدخل ثابت كل 10 ثواني!')
                .setColor('#FFD700')
                .setTimestamp()
                .setFooter({ text: `طلبت بواسطة: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

            const houseListings = [];
            for (let i = 1; i <= 5; i++) {
                const houseData = await db.get(`house_${i}`) || {}; // Ensure it returns an object
                const owner = houseData.owner ? `<@${houseData.owner}>` : 'متاح للبيع';
                const status = houseData.owner ? `🔒 تم البيع إلى ${owner}` : '🟢 متاح للبيع';
                const price = houseData.price || 500000;
                const income = houseData.income || 50000;

                houseListings.push({
                    name: `🏠 منزل #${i}`,
                    value: `💲 **السعر:** $${price.toLocaleString()}\n📈 **الدخل:** $${income.toLocaleString()} كل 10 ثواني\n📌 **الحالة:** ${status}`,
                    inline: false
                });
            }

            embed.addFields(houseListings);
            message.reply({ embeds: [embed] });

        } catch (error) {
            console.error('❌ خطأ أثناء عرض المنازل:', error);
            message.reply('⚠️ حدث خطأ أثناء تحميل قائمة المنازل. يرجى المحاولة لاحقًا.');
        }
    }
};
