module.exports = {
    name: 'حظ',
    description: 'Give a random luck amount',
    async execute(message, db, config) {
        try {
            const userId = message.author.id;
            let currentBalance = await db.get(`balance_${userId}`) || 0;

            // Calculate the luck amount
            const luckAmount = Math.floor(Math.random() * config.luckMaxAmount) + config.luckMinAmount;
            const newBalance = currentBalance + luckAmount;

            // Update the user's balance in the database
            await db.set(`balance_${userId}`, newBalance);

            // Send the luck message with the old balance and updated balance
            message.reply(`🎉 حظك هالوقت\n💸 المبلغ: $${luckAmount.toLocaleString()}\n💵 رصيدك السابق: $${currentBalance.toLocaleString()}\n🏦 رصيدك الحالي: $${newBalance.toLocaleString()}`);
        } catch (error) {
            console.error('Error executing حظ command:', error);
            message.reply('حدث خطأ أثناء محاولة حساب حظك.');
        }
    }
};
