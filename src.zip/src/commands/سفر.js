module.exports = {
    name: 'سفر',
    description: 'شراء درع لحماية نفسك من السرقة',
    async execute(message, db, config, args) {
        try {
            const userId = message.author.id;

            // Check if the user already has an active shield
            const existingShield = await db.get(`shield_${userId}`);
            if (existingShield && existingShield > Date.now()) {
                const timeLeft = Math.ceil((existingShield - Date.now()) / (1000 * 60 * 60));
                return message.reply(`لديك درع نشط لمدة ${timeLeft} ساعة(s) أخرى. لا يمكنك شراء درع جديد الآن.`);
            }

            // Validate input
            if (args.length < 1 || isNaN(args[0])) {
                return message.reply(`يرجى تحديد عدد الساعات التي ترغب في شراء السفر لها (بحد أقصى ${config.shieldMaxHours} ساعات).`);
            }

            const shieldHours = parseInt(args[0]);

            // Check if the number of hours is within the allowed range
            if (shieldHours < 1 || shieldHours > config.shieldMaxHours) {
                return message.reply(`يمكنك شراء السفر لمدة تتراوح بين 1 إلى ${config.shieldMaxHours} ساعات فقط.`);
            }

            // Calculate cost
            const shieldCost = shieldHours * config.shieldCostPerHour;
            let userBalance = await db.get(`balance_${userId}`) || 0;

            // Check if user has enough balance
            if (userBalance < shieldCost) {
                return message.reply(`ليس لديك رصيد كافٍ لشراء السفر لمدة ${shieldHours} ساعات. التكلفة الإجمالية هي $${shieldCost.toLocaleString()}.`);
            }

            // Deduct cost from balance
            userBalance -= shieldCost;
            await db.set(`balance_${userId}`, userBalance);

            // Set shield expiration time
            const shieldExpiry = Date.now() + shieldHours * 60 * 60 * 1000;
            await db.set(`shield_${userId}`, shieldExpiry);

            // Confirm shield purchase
            message.reply(`لقد سفرت لمدة ${shieldHours} ساعات! لا يمكن لأحد أن ينهبك حتى تعود من السفر. رصيدك الحالي هو $${userBalance.toLocaleString()}.`);
        } catch (error) {
            console.error('Error executing حماية command:', error);
            message.reply('حدث خطأ أثناء محاولة شراء السفر.');
        }
    }
};
