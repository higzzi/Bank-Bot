const { isInCooldown, setCooldown } = require('../utils/cooldown.js');

module.exports = {
    name: 'نهب',
    description: '💰 سرقة مبلغ عشوائي من مستخدم آخر',
    async execute(message, db, config, args) {
        try {
            const thiefId = message.author.id;

            // Check cooldown
            const timeLeft = isInCooldown('نهب', thiefId, config);
            if (timeLeft) {
                return message.reply(`⏳ يرجى الانتظار ${timeLeft} قبل استخدام الأمر مرة أخرى.`);
            }

            // Validate mentioned user
            if (args.length < 1) {
                return message.reply('⚠️ يرجى الإشارة إلى المستخدم الذي تريد نهبه.');
            }

            const targetUser = message.mentions.users.first();
            if (!targetUser) {
                return message.reply('⚠️ يرجى الإشارة إلى مستخدم صالح.');
            }

            const targetId = targetUser.id;

            // Prevent self-theft
            if (thiefId === targetId) {
                return message.reply('❌ لا يمكنك نهب نفسك!');
            }

            // Check if target has an active shield
            const shieldExpiry = await db.get(`shield_${targetId}`);
            if (shieldExpiry && shieldExpiry > Date.now()) {
                return message.reply('🛡️ هذا المستخدم لديه حماية نشطة ولا يمكن نهبه الآن.');
            }

            // Retrieve balances
            let thiefBalance = await db.get(`balance_${thiefId}`) || 0;
            let targetBalance = await db.get(`balance_${targetId}`) || 0;

            if (targetBalance <= 0) {
                return message.reply('❌ لا يمتلك هذا المستخدم رصيداً كافياً للنهب.');
            }

            // Random steal percentage (between 5% and 15%)
            const stealPercentage = Math.random() * (0.15 - 0.05) + 0.05;
            let stealAmount = Math.round(targetBalance * stealPercentage);

            // Ensure a minimum steal amount
            if (stealAmount < 100) {
                stealAmount = Math.min(100, targetBalance); // Steal at least $100 or remaining balance
            }

            // Adjust balances
            thiefBalance += stealAmount;
            targetBalance -= stealAmount;

            // Update balances in the database
            await db.set(`balance_${thiefId}`, thiefBalance);
            await db.set(`balance_${targetId}`, targetBalance);

            // Apply cooldown
            setCooldown('نهب', thiefId, config.cooldowns['نهب']);

            // Notify the thief
            message.reply(`💰 **لقد نهبت ${targetUser.tag} وسرقت $${stealAmount.toLocaleString()}!**\n🏦 رصيدك الحالي: **$${thiefBalance.toLocaleString()}**`);

            // Attempt to notify the target user in DM
            try {
                await targetUser.send(`⚠️ **تم نهبك من قبل ${message.author.tag} وسرقت $${stealAmount.toLocaleString()}.**\n💰 رصيدك الحالي: **$${targetBalance.toLocaleString()}**`);
            } catch (error) {
                console.error(`❌ تعذر إرسال رسالة خاصة إلى ${targetUser.tag}.`);
            }

            // Log for debugging
            console.log(`User ${message.author.tag} stole $${stealAmount} from ${targetUser.tag}`);
        } catch (error) {
            console.error('❌ خطأ أثناء تنفيذ أمر "نهب":', error);
            message.reply('⚠️ حدث خطأ أثناء محاولة النهب. يرجى المحاولة مرة أخرى لاحقًا.');
        }
    }
};
