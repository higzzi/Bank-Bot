module.exports = {
    name: 'قمار',
    description: '🎲 قم بالمقامرة بأموالك مع خيارات كل، نصف، ربع، أو مبلغ محدد',
    async execute(message, db, config, args) {
        try {
            const userId = message.author.id;
            let currentBalance = await db.get(`balance_${userId}`) || 0;

            if (currentBalance <= 0) {
                return message.reply('⚠️ ليس لديك رصيد كافٍ للمقامرة.');
            }

            let betAmount;
            let gambleType = args[0];

            if (!isNaN(gambleType)) {
                betAmount = parseInt(gambleType, 10);
            } else {
                switch (gambleType) {
                    case 'نص':
                        betAmount = Math.round(currentBalance / 2);
                        break;
                    case 'ربع':
                        betAmount = Math.round(currentBalance / 4);
                        break;
                    case 'كل':
                        betAmount = currentBalance;
                        break;
                    default:
                        return message.reply('❌ يرجى تحديد مبلغ صحيح (كل، نص، ربع، أو تحديد مبلغ معين).');
                }
            }

            if (betAmount <= 0 || betAmount > currentBalance) {
                return message.reply('❌ لا يمكنك المراهنة بأكثر من رصيدك الحالي.');
            }

            const isWin = Math.random() < 0.5;
            const multiplier = isWin ? config.gambleMultiplier : 1 - Math.random() * 0.3;
            const resultAmount = Math.round(betAmount * multiplier);
            const balanceChange = isWin ? (resultAmount - betAmount) : -(betAmount - resultAmount);
            const newBalance = Math.max(0, currentBalance + balanceChange); // Prevents negative balance

            await db.set(`balance_${userId}`, newBalance);

            let messageContent = isWin
                ? `🎉 **ربحت القمار بنسبة ${Math.round((multiplier - 1) * 100)}%**\n💰 **الربح:** $${resultAmount.toLocaleString()}\n💵 **رصيدك السابق:** $${currentBalance.toLocaleString()}\n🏦 **رصيدك الحالي:** $${newBalance.toLocaleString()}`
                : `😢 **خسرت القمار بنسبة ${Math.round((1 - multiplier) * 100)}%**\n💸 **الخسارة:** $${Math.abs(balanceChange).toLocaleString()}\n💵 **رصيدك السابق:** $${currentBalance.toLocaleString()}\n🏦 **رصيدك الحالي:** $${newBalance.toLocaleString()}`;

            message.reply({
                content: messageContent,
                allowedMentions: { repliedUser: false }
            });

        } catch (error) {
            console.error('❌ خطأ أثناء تنفيذ القمار:', error);
            message.reply('⚠️ حدث خطأ أثناء محاولة تنفيذ القمار. يرجى المحاولة مرة أخرى.');
        }
    }
};
