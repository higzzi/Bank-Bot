module.exports = {
    name: 'فلوسي',
    description: '🧾 تحقق من رصيدك الحالي',
    async execute(message, db, config) {
        try {
            const userId = message.author.id;
            let currentBalance = await db.get(`balance_${userId}`) || 0;

            if (currentBalance < 0) {
                currentBalance = 0; // Handle case where balance might be negative
            }

            const responseMessage = `📊 **رصيدك الحالي هو:** $${currentBalance.toLocaleString()}`;

            message.reply({
                content: responseMessage,
                allowedMentions: { repliedUser: false }
            });
        } catch (error) {
            console.error('❌ خطأ أثناء جلب الرصيد:', error);
            message.reply('⚠️ **حدث خطأ أثناء محاولة عرض الرصيد. يرجى المحاولة مرة أخرى.**');
        }
    }
};
