const ms = require('ms');

module.exports = {
    name: 'قرض',
    description: '📉 احصل على قرض مالي لفترة محدودة',
    async execute(message, db, config) {
        try {
            const userId = message.author.id;
            let currentBalance = await db.get(`balance_${userId}`) || 0;
            const existingLoan = await db.get(`loan_${userId}`);

            if (existingLoan && existingLoan > 0) {
                return message.reply('⚠️ لديك قرض قائم بالفعل. يجب تسديد القرض الحالي قبل أخذ قرض جديد.');
            }

            const loanAmount = 100000;
            currentBalance += loanAmount;

            await db.set(`balance_${userId}`, currentBalance);
            await db.set(`loan_${userId}`, loanAmount);
            await db.set(`loan_time_${userId}`, Date.now());

            message.reply(`✅ **تم إصدار قرض بقيمة** $${loanAmount.toLocaleString()}.\n💸 **سيتم خصم المبلغ بعد ساعة، تأكد من وجود رصيد كافٍ.**`);

            setTimeout(async () => {
                try {
                    let updatedBalance = await db.get(`balance_${userId}`) || 0;
                    const outstandingLoan = await db.get(`loan_${userId}`);

                    if (!outstandingLoan) return; // Avoids unnecessary deductions if the loan was already paid

                    if (updatedBalance >= outstandingLoan) {
                        updatedBalance -= outstandingLoan;
                        await db.set(`balance_${userId}`, updatedBalance);
                        await db.delete(`loan_${userId}`);
                        await db.delete(`loan_time_${userId}`);

                        message.reply(`🔻 **تم سحب مبلغ القرض البالغ $${outstandingLoan.toLocaleString()} من حسابك.**\n💰 **رصيدك الحالي:** $${updatedBalance.toLocaleString()}`);
                    } else {
                        message.reply(`❌ **رصيدك غير كافٍ لسحب القرض.**\n⚠️ **يرجى زيادة رصيدك لتجنب العواقب المالية.**`);
                    }
                } catch (error) {
                    console.error('❌ خطأ أثناء خصم القرض:', error);
                }
            }, ms('1h'));

        } catch (error) {
            console.error('❌ خطأ أثناء تنفيذ أمر القرض:', error);
            message.reply('⚠️ **حدث خطأ أثناء محاولة إصدار القرض. يرجى المحاولة مرة أخرى لاحقًا.**');
        }
    }
};
