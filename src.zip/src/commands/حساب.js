module.exports = {
    name: 'حساب',
    description: 'عرض معلومات الحساب الشخصي',
    async execute(message, db) {
        try {
            const userId = message.author.id;
            const balance = await db.get(`balance_${userId}`) || 0;
            const loanAmount = await db.get(`loan_${userId}`) || 0;
            const userCompanies = await db.get(`user_${userId}_companies`) || [];

            const companyNames = userCompanies.map(companyId => {
                const company = companies.find(c => c.id === companyId);
                return company ? company.name : 'شركة غير معروفة';
            }).join(', ');

            message.reply(`رصيدك الحالي: $${balance.toLocaleString()}\n` +
                          `مبلغ القرض: $${loanAmount.toLocaleString()}\n` +
                          `الشركات المملوكة: ${companyNames.length > 0 ? companyNames : 'أنت لا تمتلك أي شركات'}`);
        } catch (error) {
            console.error('Error executing حساب command:', error);
            message.reply('حدث خطأ أثناء محاولة عرض معلومات الحساب. يرجى المحاولة مرة أخرى.');
        }
    }
};
