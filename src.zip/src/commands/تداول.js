module.exports = {
    name: 'تداول',
    description: 'تداول الأموال بمخاطرة عالية ومكافأة كبيرة',
    async execute(message, db, config, args) {
        try {
            const userId = message.author.id;
            let currentBalance = await db.get(`balance_${userId}`) || 0;

            if (currentBalance <= 0) {
                return message.reply('❌ ليس لديك رصيد كافٍ للتداول.');
            }

            // Determine trade amount based on the type
            let tradingType = args[0];
            let tradingAmount;

            switch (tradingType) {
                case 'نص':
                    tradingAmount = Math.round(currentBalance / 2);
                    break;
                case 'ربع':
                    tradingAmount = Math.round(currentBalance / 4);
                    break;
                case 'كل':
                default:
                    tradingAmount = currentBalance;
                    break;
            }

            // Ensure user has enough balance for the trade
            if (tradingAmount <= 0 || currentBalance < tradingAmount) {
                return message.reply('❌ لا يمكنك التداول بهذا المبلغ. تأكد من أن لديك رصيد كافٍ.');
            }

            // Trade outcome (40% win chance)
            const winChance = 0.4;
            const isWin = Math.random() < winChance;

            // New multipliers (50% max profit and 30% max loss)
            const multiplier = isWin ? (1 + Math.random() * 0.5) : (1 - Math.random() * 0.3);

            // Calculate new balance
            const resultAmount = Math.round(tradingAmount * multiplier);
            const newBalance = Math.max(0, currentBalance - tradingAmount + resultAmount);

            // Update balance in database
            await db.set(`balance_${userId}`, newBalance);

            // Prepare trade result message
            let messageContent;
            if (isWin) {
                const profitPercentage = Math.round((multiplier - 1) * 100);
                messageContent = `🚀 **صفقة تداول رابحة!**\n📈 الربح: **+${profitPercentage}%**\n💰 مبلغ الربح: **$${resultAmount.toLocaleString()}**\n💵 رصيدك السابق: **$${currentBalance.toLocaleString()}**\n🏦 رصيدك الحالي: **$${newBalance.toLocaleString()}**`;
            } else {
                const lossPercentage = Math.round((1 - multiplier) * 100);
                const lossAmount = Math.abs(tradingAmount - resultAmount);
                messageContent = `😢 **صفقة تداول خاسرة...**\n📉 الخسارة: **-${lossPercentage}%**\n💸 مبلغ الخسارة: **$${lossAmount.toLocaleString()}**\n💵 رصيدك السابق: **$${currentBalance.toLocaleString()}**\n🏦 رصيدك الحالي: **$${newBalance.toLocaleString()}**`;
            }

            // Send the result message to the user
            message.reply({
                content: messageContent,
                allowedMentions: { repliedUser: false }
            });

            // Log details for debugging and analysis
            console.log('User:', userId);
            console.log('Trading Type:', tradingType);
            console.log('Trading Amount:', tradingAmount);
            console.log('Multiplier:', multiplier.toFixed(2));
            console.log('Result Amount:', resultAmount);
            console.log('New Balance:', newBalance);

        } catch (error) {
            console.error('❌ خطأ أثناء تنفيذ أمر التداول:', error);
            message.reply('⚠️ حدث خطأ أثناء محاولة التداول. يرجى المحاولة مرة أخرى لاحقًا.');
        }
    }
};
