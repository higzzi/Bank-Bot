const { isInCooldown, setCooldown } = require('../utils/cooldown.js');

module.exports = {
    name: 'استثمار',
    description: 'Invest money with risk',
    async execute(message, db, config, args) {
        const userId = message.author.id;

        // Check if the user is in cooldown
        if (isInCooldown(userId)) {
            return message.reply('انتظر قليلاً قبل أن تتمكن من الاستثمار مرة أخرى.');
        }

        let currentBalance = await db.get(`balance_${userId}`) || 0;

        if (currentBalance <= 0) {
            return message.reply('ليس لديك رصيد كافي للاستثمار.');
        }

        let investmentType = args[0];
        let investmentAmount;

        // Determine the investment amount based on the user's choice
        switch (investmentType) {
            case 'نص':
                investmentAmount = Math.round(currentBalance / 2);
                break;
            case 'ربع':
                investmentAmount = Math.round(currentBalance / 4);
                break;
            case 'كل':
            default:
                investmentAmount = currentBalance;
                break;
        }

        // Simulate the investment outcome
        const isWin = Math.random() < 0.5;
        const multiplier = isWin ? config.investmentMultiplier : 1 - Math.random() * 0.3;
        const resultAmount = Math.round(investmentAmount * multiplier);
        const newBalance = currentBalance - investmentAmount + resultAmount;

        // Update the user's balance in the database
        await db.set(`balance_${userId}`, newBalance);

        // Set cooldown for the user
        setCooldown(userId);

        // Generate the message content
        let messageContent;
        if (isWin) {
            messageContent = `🎉 استثمار ناجح بنسبة ${Math.round((multiplier - 1) * 100)}%\n` +
                             `مبلغ الربح: $${resultAmount.toLocaleString()}\n` +
                             `رصيدك السابق: $${currentBalance.toLocaleString()}\n` +
                             `رصيدك الحالي: $${newBalance.toLocaleString()}`;
        } else {
            messageContent = `😢 استثمار خاسر بنسبة ${Math.round((1 - multiplier) * 100)}%\n` +
                             `مبلغ الخسارة: $${Math.abs(resultAmount).toLocaleString()}\n` +
                             `رصيدك السابق: $${currentBalance.toLocaleString()}\n` +
                             `رصيدك الحالي: $${newBalance.toLocaleString()}`;
        }

        // Send the message to the user
        message.reply({
            content: messageContent,
            allowedMentions: { repliedUser: false }
        });
    }
};
