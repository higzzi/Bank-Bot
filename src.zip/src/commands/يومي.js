module.exports = {
    name: 'يومي',
    description: 'احصل على هدية يومية عشوائية من المال',
    async execute(message, db, config) {
        try {
            const userId = message.author.id;
            const cooldownKey = `cooldown_daily_${userId}`;
            const lastUsed = await db.get(cooldownKey);
            const now = Date.now();
            const cooldownTime = config.cooldowns['يومي'];

            // Check if the cooldown is still active
            if (lastUsed && now - lastUsed < cooldownTime) {
                const remainingTime = cooldownTime - (now - lastUsed);
                const hours = Math.floor(remainingTime / (1000 * 60 * 60));
                const minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);

                return message.reply(`⏳ يرجى الانتظار قبل الحصول على الهدية اليومية مرة أخرى!\nالوقت المتبقي: ${hours} ساعات و ${minutes} دقائق و ${seconds} ثوانٍ.`);
            }

            // Generate a random gift amount (between 1000 and 6000)
            const giftAmount = Math.floor(Math.random() * 5000) + 1000;

            // Get and update user balance
            let userBalance = await db.get(`balance_${userId}`) || 0;
            userBalance += giftAmount;

            // Save new balance and cooldown time
            await db.set(`balance_${userId}`, userBalance);
            await db.set(cooldownKey, now);

            // Send success message
            message.reply(`🎁 مبروك! لقد حصلت على هدية يومية بقيمة **$${giftAmount.toLocaleString()}**!\n💰 رصيدك الحالي: **$${userBalance.toLocaleString()}**.`);
        } catch (error) {
            console.error(`❌ خطأ أثناء تنفيذ أمر "يومي":`, error);
            message.reply('⚠️ حدث خطأ أثناء محاولة الحصول على الهدية اليومية. يرجى المحاولة مرة أخرى لاحقًا.');
        }
    }
};
