module.exports = [
    {
        id: 1,
        name: 'شركة ويك',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_1_owner'
    },
    {
        id: 2,
        name: 'شركة ريال مدريد',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_2_owner'
    },
    {
        id: 3,
        name: 'شركة عباس ابو العمبة',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_3_owner'
    },
    {
        id: 4,
        name: 'شركة حسوني السجاج',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_4_owner'
    },
    {
        id: 5,
        name: 'شركة علي قاهرهم',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_5_owner'
    },
    {
        id: 6,
        name: 'شركة احمد سجينة',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_6_owner'
    },
    {
        id: 7,
        name: 'شركة عادل بطحة',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_7_owner'
    },
    {
        id: 8,
        name: 'شركة جبار ابو الشربت',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_8_owner'
    },
    {
        id: 9,
        name: 'شركة سجاد الكهربائي',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_9_owner'
    },
    {
        id: 10,
        name: 'شركة انشتاين ابو اللبلبي',
        price: 100000000,
        rent: 50000000,
        owner: null,
        dbKey: 'company_10_owner'
    }
];
