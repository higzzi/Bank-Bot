// Update By Ghlais

module.exports = {
    name: 'وظيفة',
    description: 'اختيار وظيفة جديدة',

    async execute(message, db, config, args) {
        const userId = message.author.id;

        let currentBalance = await db.get(`balance_${userId}`) || 0;

        if (currentBalance <= 0) {
            return message.reply('❌ ليس لديك رصيد كافٍ للقيام بأي عملية.');
        }

        // If no argument is provided, show the job list
        if (!args[0]) {
            const jobList = config.jobTitles.map((job, index) => 
                `🔹 **${index + 1}. ${job.name}**\n💵 **التكلفة**: $${job.cost}\n💰 **الراتب الشهري**: $${job.salary}\n`
            ).join('\n');

            return message.reply(`يرجى اختيار وظيفة من القائمة التالية:\n\n${jobList}\nاستخدم الرقم المناسب لاختيار الوظيفة.`);
        }

        // Parse the job index from the argument (e.g., '1' -> index 0)
        const jobIndex = parseInt(args[0]) - 1; // Convert to zero-indexed
        const selectedJob = config.jobTitles[jobIndex];

        if (!selectedJob) {
            return message.reply('🚫 الوظيفة التي حددتها غير متاحة. يرجى اختيار وظيفة من القائمة.');
        }

        const jobCost = selectedJob.cost;

        if (currentBalance < jobCost) {
            return message.reply(`❌ ليس لديك مال كافٍ للحصول على وظيفة **${selectedJob.name}**. تحتاج إلى **$${jobCost}**.`);
        }

        // Deduct cost and assign job
        const newBalance = currentBalance - jobCost;
        await db.set(`balance_${userId}`, newBalance);
        await db.set(`job_${userId}`, selectedJob.name);
        await db.set(`salary_${userId}`, selectedJob.salary);

        return message.reply(`🎉 تهانينا! لقد حصلت على وظيفة **${selectedJob.name}**\n\n💵 **التكلفة**: $${jobCost}\n💰 **راتبك الجديد**: $${selectedJob.salary}\n💸 **رصيدك الحالي**: $${newBalance.toLocaleString()}.`);
    }
};

